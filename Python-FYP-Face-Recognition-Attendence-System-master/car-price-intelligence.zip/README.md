
# 🚗 Car Price Intelligence Platform

Production-grade ML system for predicting used car prices.

## Features
- LightGBM model training
- Feature engineering pipeline
- FastAPI inference service
- Streamlit dashboard
- Docker-ready deployment
- Monitoring & drift detection ready

## Run Locally

Install dependencies:
    pip install -r requirements.txt

Train model:
    python src/train.py

Run API:
    uvicorn app.main:app --reload

Run Streamlit:
    streamlit run app/streamlit_app.py
