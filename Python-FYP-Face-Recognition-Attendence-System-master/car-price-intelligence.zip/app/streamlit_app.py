
import streamlit as st
import pickle
import pandas as pd

model = pickle.load(open("models/model.pkl", "rb"))

st.title("Car Price Prediction")

year = st.number_input("Year", 2000, 2025)
engine = st.number_input("Engine Size")
mileage = st.number_input("Mileage")

if st.button("Predict"):
    car_age = 2025 - year
    input_df = pd.DataFrame([{
        "Engine Size": engine,
        "Mileage": mileage,
        "Car_Age": car_age
    }])
    prediction = model.predict(input_df)
    st.success(f"Estimated Price: ${prediction[0]:,.2f}")
