
from fastapi import FastAPI
import pickle
import pandas as pd

app = FastAPI()
model = pickle.load(open("models/model.pkl", "rb"))

@app.post("/predict")
def predict(data: dict):
    df = pd.DataFrame([data])
    prediction = model.predict(df)
    return {"predicted_price": float(prediction[0])}
